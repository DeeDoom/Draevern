
export default function Home() {
  return (
    <main style={{
      backgroundColor: '#000',
      color: '#fff',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem'
    }}>
      <h1 style={{
        fontSize: '3rem',
        fontWeight: 'bold',
        letterSpacing: '0.05em'
      }}>
        DRÆVERN
      </h1>
      <p style={{
        marginTop: '1rem',
        fontSize: '1.2rem',
        color: '#aaa',
        maxWidth: '600px',
        textAlign: 'center'
      }}>
        Monolith No.00 — Limitovaná série. Každý flakon je artefakt.
      </p>
      <a href="#"
         style={{
           marginTop: '2rem',
           backgroundColor: '#fff',
           color: '#000',
           padding: '0.75rem 2rem',
           borderRadius: '9999px',
           fontWeight: '500',
           textDecoration: 'none'
         }}>
        Získat přístup
      </a>
      <div style={{
        marginTop: '4rem',
        maxWidth: '700px',
        textAlign: 'center',
        color: '#666'
      }}>
        <p>
          Vstup do světa, kde vůně nejsou jen vůněmi. DRÆVERN je rituál. Proměna.
          Každá kapka je klíč k nové podobě tebe.
        </p>
      </div>
    </main>
  );
}
